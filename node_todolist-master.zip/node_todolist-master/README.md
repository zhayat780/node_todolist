# node_todolist
The NodeJS ToDoList application, without a Vagrantfile  

Reference for **Creating a Developer Environment**
